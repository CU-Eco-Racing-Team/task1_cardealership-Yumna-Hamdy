from django.apps import AppConfig


class DealershopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dealershop'
